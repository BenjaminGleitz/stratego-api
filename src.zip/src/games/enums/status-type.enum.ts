export enum StatusType{
    OPENED = 'OPENED',
    STARTED = 'STARTED',
    CLOSED = 'CLOSED'
}