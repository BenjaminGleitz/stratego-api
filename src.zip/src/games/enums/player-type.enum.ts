export enum PlayerType{
    RED = 'RED',
    BLUE = 'BLUE'
}